### R code from vignette source 'OrgMassSpecR-libraries.Rnw'

###################################################
### code chunk number 1: OrgMassSpecR-libraries.Rnw:73-74
###################################################
library(SpecLibExample)


###################################################
### code chunk number 2: OrgMassSpecR-libraries.Rnw:77-80 (eval = FALSE)
###################################################
## mirex.meta <- example.meta[example.meta$
##   filename == "mirex", ]
## LibraryReport(metadata = mirex.meta, pdf = TRUE)


###################################################
### code chunk number 3: OrgMassSpecR-libraries.Rnw:132-133
###################################################
head(example.spec)


